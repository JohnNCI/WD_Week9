function bottle() {
    let lyrics = ""; // Initialize an empty string to store the lyrics
    for (let i = 99; i >= 0; i--) {
        // Loop from 99 down to 0
        if (i > 2) {
            // For 3 or more bottles
            lyrics += i + " bottles of beer on the wall,";
            lyrics += i + " bottles of beer!<br />";
            lyrics += "Take one down,";
            lyrics += "Pass it around,";
            lyrics += (i - 1) + " bottles of beer on the wall!<br /><br /><br />";
        } else if (i == 2) {
            // For 2 bottles
            lyrics += i + " bottles of beer on the wall,";
            lyrics += i + " bottles of beer!<br />";
            lyrics += "Take one down,";
            lyrics += "Pass it around,";
            lyrics += (i - 1) + " bottle of beer on the wall!<br /><br /><br />";
        } else if (i == 1) {
            // For 1 bottle
            lyrics += i + " bottle of beer on the wall,";
            lyrics += i + " bottle of beer!<br />";
            lyrics += "Take one down,";
            lyrics += "Pass it around,";
            lyrics += "no more bottles of beer on the wall!<br />";
        } else if (i == 0) {
            // For 0 bottles
            lyrics += "No more bottles of beer on the wall, no more bottles of beer.<br />";
            lyrics += "Go to the store and buy some more, 99 bottles of beer on the wall.<br />";
        }
        lyrics += "<hr /><br />"; // Add a horizontal rule and line break after each verse
    }

    document.getElementById("song").innerHTML = lyrics;
    // Display the lyrics in the div with id "song"
}