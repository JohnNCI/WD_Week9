// Array of possible choices
const possiblechoices = ['rock', 'paper', 'scissor'];
let win = 0; 
let playCount = 0;

// Function to handle user's choice
function Play(userchoice) {
    // Generate a random choice for the computer
    let computerchoice = Math.floor((Math.random() * 3) + 0); // this gives 0 or 1 or 2
    let comp = possiblechoices[computerchoice];
    let user = possiblechoices[userchoice];

    // Display user and computer choices
    document.getElementById("uchoice").innerHTML = "user choice is " + user;
    document.getElementById("cchoice").innerHTML = "computer choice is " + comp;
    
    // Check the game rules
    checkRules(comp, user); 
    
    // Display the number of times played
    document.getElementById("count").innerHTML = "You played " + playCount + " times";
}

// Function to check the game rules and determine the winner
function checkRules(comp, user) {
    // Check if the computer's choice is the same as the user's choice
    if (comp === user) {
        document.getElementById("result").innerHTML = "its a tie";
    } 
    // Check if the user's choice is 'rock'
    else if (user === 'rock') {
        // If the computer's choice is 'paper', the computer wins
        if (comp === 'paper') {
            document.getElementById("result").innerHTML = "paper covers rock, computer wins";
        } 
        // If the computer's choice is 'scissor', the user wins
        else if (comp === 'scissor') {
            document.getElementById("result").innerHTML = "rock crushes scissor, user wins";
            win++; // Increment the user's win count
        }
    } 
    // Check if the user's choice is 'paper'
    else if (user === 'paper') {
        // If the computer's choice is 'rock', the user wins
        if (comp === 'rock') {
            document.getElementById("result").innerHTML = "paper covers rock, user wins";
            win++; // Increment the user's win count
        } 
        // If the computer's choice is 'scissor', the computer wins
        else if (comp === 'scissor') {
            document.getElementById("result").innerHTML = "scissor cut paper, computer wins";
        }
    } 
    // Check if the user's choice is 'scissor'
    else if (user === 'scissor') {
        // If the computer's choice is 'rock', the computer wins
        if (comp === 'rock') {
            document.getElementById("result").innerHTML = "rock crushes scissor, computer wins";
        } 
        // If the computer's choice is 'paper', the user wins
        else if (comp === 'paper') {
            document.getElementById("result").innerHTML = "scissor cut paper, user wins";
            win++; // Increment the user's win count
        }
    }
    playCount++; // Increment the play count
    // Check if the play count has reached 3
    if (playCount == 3) {
        endGame(); // Call the endGame function
    } 
}

// Function to end the game and display the final result
function endGame() {
    if (win >= 2) {
        document.getElementById("Totalresult").innerHTML = "<h1> You Won !!!!</h1>";
    } else {
        document.getElementById("Totalresult").innerHTML = "<h1> Computer Won !!!!</h1>";
    }
}